<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                    <tr>
                        <th>Id</th>
                        <th>name</th>
                        <th>mobile</th>
                        <th>email</th>
                        <th>father</th>
                        <th>password</th>
                        <th>confirmpassword</th>
                        <th>catchcode</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $membership; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($x->id); ?>

                            </td>
                            <td>
                                <?php echo e($x->name); ?>

                            </td>
                            <td>
                                <?php echo e($x->mobile); ?>

                            </td>
                            <td>
                                <?php echo e($x->email); ?>

                            </td>
                            <td>
                                <?php echo e($x->father); ?>

                            </td>
                            <td>
                                <?php echo e($x->password); ?>

                            </td>
                            <td>
                                <?php echo e($x->confirmpassword); ?>

                            </td>
                            <td>
                                <?php echo e($x->catchcode); ?>

                            </td>
                            <td>
                                <a href="#"><span class="fa fa-trash" style="color:red;"></span></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("Adminpages.AdminMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/Adminpages/memberdetail.blade.php ENDPATH**/ ?>