<h1>Tis is dashboardpages</h1>
<?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/dashboard.blade.php ENDPATH**/ ?>