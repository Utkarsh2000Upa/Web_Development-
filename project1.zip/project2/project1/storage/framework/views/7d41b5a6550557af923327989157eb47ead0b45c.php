<html>
<head>
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrp.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
<div class="container-fluid">
    <div class="row" style="min-height: 20px">
        <div class="col-sm-3" style="margin-top: 12px">
            <a href="#"><img class="logo" src="images/flag.gif">
                <font>Government of india</font></a>
        </div>
        <div class="col-sm-6">
            <h2 style="text-align:center;margin-top:10px;padding:0px; color:darkmagenta"><marquee behavior="alternate" scrollamount="8">SWACHH BHARAT ABHIYAN</marquee></h2>
        </div>
        <div class="col-sm-3">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.facebook.com/login/?next=https%3A%2F%2Fwww.facebook.com%2FSBMGramin%2F" style="border-right:1px solid black;color:blue"><span class="fa fa-facebook fa-2x" style="font-size: 20px;font-weight:50"></span></a></li>
                <li><a href="https://twitter.com/swachhbharat" style="border-right:1px solid black; color:darkblue"><span class="fa fa-twitter fa-2x" style="font-size: 20px;font-weight:50"></span></a></li>
                <li><a href="https://www.youtube.com/channel/UCo_Itwq5Oyfq7Jk4Soik-UA" style="border-right:1px solid black; color:red"><span class="fa fa-youtube fa-2x" style="font-size: 20px;font-weight:50"></span></a></li>
                <li><a href="login" style="border-right:1px solid black"><span class="fa fa-user" style="font-size:20px;"></span>Login</a></li>
            </ul>
        </div>
    </div>
    <div class="row" style="padding: 0px;margin-top: 0px">
        <div class="col-md-1" style="min-height:100px;background:teal;"></div>
        <div class="col-md-3" style="min-height:100px;background: teal;">
            <img src="images/logo.png" height="100" width="100%"/>
        </div>
        <div class="col-md-8" style="padding:0px;min-height:100px;">
            <nav class="navbar navbar-default menu">
                <ul class="nav navbar-nav" style="background:teal">
                    <li><a href="Index/" style="color:white;"><span class="fa fa-home">Home</span></a></li>
                    <li><a href="/scheme" style="color:white"><span class="fa fa-th-list">Scheme</span></a></li>
                    <li><a href="/membership" style="color:white"><span class="fa fa-users">Membership</span></a></li>
                    <li><a href="/contact" style="color:white"><span class="fa fa-phone">Contact Us</span></a></li>
                    <li><a href="/login" style="color:white"><span class="fa fa-user">Login</span></a></li>
                    <li><a href="/donation" style="color:white">Donation</a></li>
                    <li><a href="/member" style="color:white"><span class="fa fa-user">Member</span></a></li>
                    <li><a href="/suggestion" style="color:white">Suggestion</a></li>
                    <li><a href="/image" style="color:white"><span class="fa fa-picture-o">Image Gallery</span></a></li>
                    <li><a href="/Media" style="color:white"><span class="fa fa-facebook">Social media</span></a></li>
                    <li><a href="/dashboard" style="color:white"><span class="fa fa-dashboard">Dashboard</span></a></li>
                </ul>
            </nav>
        </div>
    </div>
        <div class="row">
         <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" style="min-height:180px;background:darkslategrey;border-bottom:1px solid white">
            <div class="container">
                <div class="row">
                    <div class="col-md-2" style="min-height:180px;background:darkslategrey;text-align:left;font-size:14px;padding:20px;margin-top: 50px">

                        <a href="https://swachhbharat.mygov.in/" style="color:lightgray">Home</a><br>
                        <a href="https://secure.mygov.in/feedback/" style="color:lightgray">Feedback</a><br>
                        <a href="https://www.mygov.in/simple-page/associate-mygov/" style="color:lightgray">Associate With Mygov</a><br>
                        <a href="https://swachhbharat.mygov.in/shs-2019" style="color:lightgray">SHS 2019</a><br>

                    </div>
                    <div class="col-md-2" style="min-height:200px;background:darkslategrey;text-align:left;font-size:14px;padding:20px;margin-top: 50px">
                        <a href="https://www.mygov.in/overview/" style="color:lightgray">About us</a><br>
                        <a href="https://www.mygov.in/sitemap/" style="color:lightgray">Sitemap</a><br>
                        <a href="https://www.mygov.in/simple-page/link-us/" style="color:lightgray">Link to us</a><br>
                        <a href="https://swachhbharat.mygov.in/swachhata-pakhwada-meity" style="color:lightgray">Swachhta Pakhwada 2020 Activities</a><br>

                    </div>
                    <div class="col-md-2" style="min-height:200px;background:darkslategrey;text-align:left;font-size:14px;padding:25px;margin-top: 50px">
                        <a href="https://www.mygov.in/simple-page/terms-conditions/" style="color:lightgray">Terms & Condition</a><br>
                        <a href="https://www.mygov.in/mygov-faq/" style="color:lightgray">FAQ</a><br>
                        <a href="https://www.mygov.in/simple-page/contact-us/" style="color:lightgray">Contact Us</a><br>

                    </div>
                    <div class="col-md-1" style="min-height:200px;background:darkslategrey;padding:0px;margin-top:50px;">
                        <a href="" class="logo"><img src="images/qr.jpg" height="100" width="100"/></a>
                    </div>
                    <div class="col-md-5" style="min-height:200px;background:darkslategrey;margin-top: 50px">
                        <a href="" class="logo"><img src="images/footer-logo.png" height="50" width="100"/></a>
                        <p><font color="white">MyGov platform is designed, developed and hosted by National Informatics Centre, Ministry of Electronics & Information Technology, Government of India.</font></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3" style="min-height:50px;background:lightslategray"></div>
    <div class="col-md-6" style="min-height:50px;background:lightslategray">
        <div class="row">
            <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                <img src="images/sw3.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                <img src="images/sw4.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                <img src="images/sw5.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                <img src="images/sw6.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                <img src="images/sw7.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                <img src="images/sw8.png" height="50" width="100%"/>
            </div>
        </div>
    </div>
    <div class="col-md-3" style="min-height:50px;background:lightslategray">
        <img src="images/sw9.png" height="50" width="100" style="border-right:1px solid white"/>
    </div>
</div>
<div class="row">
    <div class="col-md-3" style="min-height:50px;background:black"></div>
    <div class="col-md-6" style="min-height:50px;background:black">
        <div class="row">
            <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                <img src="images/sw10.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                <img src="images/sw11.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                <img src="images/sw12.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                <img src="images/sw13.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                <img src="images/sw14.png" height="50" width="100%"/>
            </div>
            <div class="col-md-2" style="min-height:50px;background:black;">
                <img src="images/sw15.png" height="50" width="100%"/>
            </div>
        </div>
    </div>
    <div class="col-md-3" style="min-height:50px;background:black"></div>
</div>
</div>
</body>
</html>
<?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/Master.blade.php ENDPATH**/ ?>