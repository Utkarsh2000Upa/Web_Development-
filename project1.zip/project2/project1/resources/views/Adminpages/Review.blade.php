@extends("Adminpages.AdminMaster")
@section("content")

<div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Rating</th>
                        <th>Message</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($Review as $x)
                        <tr>
                            <td>
                                {{ $x->id }}
                            </td>
                            <td>
                                {{ $x->name }}
                            </td>
                            <td>
                                {{ $x->rating}}
                            </td>
                            <td>
                                {{ $x->msg }}
                            </td>
                        
                        </tr>
                    @endforeach
                    </tbody>

                </table>
            </div>
        </div>
    </div>

@endsection

