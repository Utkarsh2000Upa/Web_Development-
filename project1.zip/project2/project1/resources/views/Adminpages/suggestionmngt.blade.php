@extends("Adminpages.AdminMaster")
@section("content")

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                    <tr>
                        <th>Id</th>
                        <th>name</th>
                        <th>mob</th>
                        <th>Your Message</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($suggestion as $x)
                        <tr>
                            <td>
                                {{ $x->id }}
                            </td>
                            <td>
                                {{ $x->name }}
                            </td>
                            <td>
                                {{ $x->mob }}
                            </td>
                            <td>
                                {{ $x->msg}}
                            </td>
                        </tr>
                    @endforeach
                    </tbody>

                </table>
            </div>
        </div>
    </div>


@endsection

