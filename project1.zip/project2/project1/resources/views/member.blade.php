@extends('master')
@section('content')

<h1>This is Member Page</h1>

@endsection
