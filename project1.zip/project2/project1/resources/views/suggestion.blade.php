@extends('master')
@section('content')
<div class="container">

    <div class="row" style="background-color:lightsalmon">
        <div class="col-sm-6" style="border:2px solid black;min-height:300px;padding:0px;" >
            <span style="color:teal;font-size:30px;margin-left:15px;">About Swachh Bharat Mission</span><br>
            <h4 style="color:black">To accelerate the efforts to achieve universal sanitation coverage and to put the focus on sanitation, the Prime Minister of India had launched the Swachh Bharat Mission on 2nd October 2014. Under the mission, all villages, Gram Panchayats, Districts, States and Union Territories in India declared themselves "open-defecation free" (ODF) by 2 October 2019, the 150th birth anniversary of Mahatma Gandhi, by constructing over 100 million toilets in rural India. To ensure that the open defecation free behaviours are sustained, no one is left behind, and that solid and liquid waste management facilities are accessible, the Mission is moving towards the next Phase II of SBMG i.e ODF-Plus. ODF Plus activities under Phase II of Swachh Bharat Mission (Grameen) will reinforce ODF behaviours and focus on providing interventions for the safe management of solid and liquid waste in villages.</h4>
        </div>
        <div class="col-sm-6" >
                <form action="/savesuggestion/" method="post" style="border:2px solid black;height:350px;width:300px;margin-left:10%;background-color: lightcyan">
                    @csrf
                    <h3>Suggestion Form:</h3><br>
                    <span>Name</span><br>
                    <input type="text" name="name" placeholder="Name"><br><br>
                    <span>Mobile</span><br>
                    <input type="number" name="mob" placeholder="Mobile"><br><br>
                    <span>Give Suggestion </span><br>
                    <textarea class="form-control" name="msg" placeholder="Messages"></textarea><br>
                    <button class="btn btn-success">Submit</button>
                </form>
        </div>
    </div><br>
    <div class="row">
        <div class="col-sm-6" style="border: 2px solid black;min-height:300px;">
            <span style="color:teal;font-size:30px;margin-left:15px;"><marquee behavior="alternate" scrollamount="15">Suggestion</marquee></span>
            <ol>
                <li>Humble suggestion for the Swachh Bharat Abhiyan. The administration should put posters and banners in public places like roads, buses trains etc displaying things like spitting, urinating in public place is uncivilized Asabhya in local languages to make at least roads and public places clean. Those indulge in such practices would be put to shame by such posters and banners. Even when travel on road, bike / scooter riders and even car drivers spit on the road making it dirty and affect other.</li><br>
                <li>Bursting of crackers after elections results announcement should be ban for atleast 24 hours. This should also be a part of model code of conduct of election commission of India in this way we can reduce the pollution in the world.</li><br>
                <li>Currently i live in Sweden. I was wowed by the waste management done here. They recycling education is done from school days and schools make it a fun trip to recycle plastic bottles and tins in the machine.
                    One such example is , all softdrinks and water bottles are charged 20% extra when buying from shops and if they are recycled at the machines in the grocery shops, we can back the amount as cash coupon. That coupon can be used to buy things from supermarket. So every supermarket has this mach</li><br>
                <li>I live in Jabalpur. I am not satified by the waste management system of the city. Waste are send to kathonda plant for burning to generate electricity. This plant is inside Jabalpur city. I want to alert you , major health issue problem in jabalpur. Each person is suffering from cough. If you do survey today you will find each person suffering from cough They are burning everything in this kathonda plant , even they are burning dead animals also. It is serious , please take action before this</li><br>
                <li>Govt should make act for new Dustbin in markt dustbin will have two cabin compulsory basis because in off course we are let off to use two separate dustbin for dry and wet garbage and in new type dustbins we will arrange dry and wet garbage in separate cabin of new type dustbins</li><br>
            </ol>
        </div>
        <div class="col-sm-6">
            <video controls="" height="300px" width="100%" style="margin-top: 25%">
                <source src="images/S02.mp4" type="video/mp4">
            </video>
        </div>
    </div>
</div><br>
    <div class="row" style="background-color: lightgreen">
        <div class="col-sm-1"></div>
        <div class="col-sm-3">
            <img src="images/I14.jpg" height="300px" width="100%">
        </div>
        <div class="col-sm-1"></div>
        <div class="col-sm-3">
            <img src="images/I6.jpg" height="300px" width="100%">
        </div>
        <div class="col-sm-1"></div>
        <div class="col-sm-3">
            <img src="images/I2.jpg" height="300px" width="100%" style="margin-right:1%">
        </div>
    </div>
    <br>
@endsection
