<html>
<head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            transition: 3s;
            background-color:lightgoldenrodyellow;
        }

        .login-container {
            margin-top: 10%;
            border: 1px solid #CCD1D1;
            border-radius: 5px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            max-width: 50%;
        }

        .ads {
            background-image: url("images/logo1.jpg");
            border-top-left-radius: 5px;
            border-bottom-left-radius: 5px;
            color: #fff;
            padding: 10px;
            text-align: center;
            border-right: 2px solid red;
            background-repeat: no-repeat;
            background-color: white;

        }

        .ads h1 {
            margin-top: 20%;
        }

        #sl {
            font-weight: 100 !important;
        }

        .profile-img {
            text-align: center;
        }

        .profile-img img {
            border-radius: 50%;
            /* animation: mymove 2s infinite; */
        }

        @keyframes mymove {
            from {border: 1px solid #F2F3F4;}
            to {border: 8px solid #F2F3F4;}
        }

        .login-form {
            padding: 15px;
        }

        .login-form h3 {
            text-align: center;
            padding-top: 15px;
            padding-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="container login-container">
    <div class="row">
        <div class="col-md-6 ads">
           
        </div>
        <div class="col-md-6 login-form" style="background-color: white">
            @csrf
            <div class="profile-img">
                <img src="images/OIP.jpg" style="height: 120px;width:100px;"/>
            </div>
            <h3>Login</h3>
            <form action="/loginRecord/" method="post">
                @csrf
                <span>UserName</span>
                <input type="text" name="aid" placeholder="UserName" required><br><br>
                <span>Password</span>
                <input type="password" name="passwd" placeholder="password" required><br><br>
                    <button  class="btn-send" style="background:lightcoral;color:white;margin-left: 40%;">Sign In</button><br><br>
                    <a href="Index">Go to Main Page</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>
