<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Homecontroller extends Controller
{
    public function Index()
    {
        return view('Index');
    }
    public function scheme()
    {
        return view('scheme');
    }
    public function membership()
    {
        return view('membership');
    }
    public function donation()
    {
        return view('donation');
    }
    public function contactUs()
    {
        return view('contactUs');
    }
    public function login()
    {
        return view('login');
    }
    public function image()
    {
        return view('image');
    }
    public function suggestion()
    {
        return view('suggestion');
    }
    public function member()
    {
        return view('member');
    }
    public function Media()
    {
        return view('Media');
    }
    public function review()
    {
        return view("review");
    }
    public function savecontact(Request $request)
    {
        $name=$request->input("name");
        $mob=$request->input("mob");
        $email=$request->input("email");
        $YourMessage=$request->input("message");
        //echo "name".$name."mobile".$mob."email".$email."message".$YourMessage;
        DB::table("contactus")->insert(["name"=>$name,"mob"=>$mob,"email"=>$email,"message"=>$YourMessage]);
        echo "<script>alert('Record saved into database');window.location.href='/contact'</script>";
    }

   public function savelogin(Request $request)
    {
        $aid=$request->input("aid");
        $passwd=$request->input("passwd");
        //echo "name".$name."password".$password;
        DB::table("tbl_login")->insert(["aid"=>$aid,"passwd"=>$passwd]);
        echo "<script>alert('Login Successfully');window.location.href='/login'</script>";
    }
    public function saveReview(Request $request)
    {
        $name=$request->input("name");
        $star=$request->input("hbn");
        $msg=$request->input("msg");
        $array=array('name'=>$name,'rating'=>$star,'msg'=>$msg);
        DB::table("review")->insert($array);
        echo "<script>alert('Thanks for Review');window.location.href='/review'</script>";
    }
    public function savemembership(Request $request)
    {
        $name=$request->input("name");
        $mob=$request->input("mob");
        $email=$request->input("email");
        $father=$request->input("father");
        $gender=$request->input('g');
        $file=$request->input("file");
        $passwd=$request->input("passwd");
        $conpasswd=$request->input("conpasswd");
        $code=$request->input("code");
        $array=array('name'=>$name,'mobile'=>$mob,'email'=>$email,'father'=>$father,'gender'=>$gender,'file'=>$file,'password'=>$passwd,'confirmpassword'=>$conpasswd,'catchcode'=>$code);
        DB::table("membership")->insert($array);
        echo "<script>alert('Welcome to Swachh Bharat Mission');window.location.href='/membership'</script>";
    }
    public function loginRecord(Request $request)
    {
        $aid=$request->input("aid");
        $passwd=$request->input("passwd");
      $arr= DB::select("select * from tbl_login where aid=? and passwd=?",[$aid,$passwd]);

        if(empty($arr))
        {
           echo "<script>alert('Invalid userid or password');window.location.href='/login'</script>";
        }
        else
        {
          echo "<script>alert('Login Successfully');window.location.href='/dashboard'</script>";
        }
    }
    public function savedonation(Request $request)
    {
        $name=$request->input("name");
        $mob=$request->input("mob");
        $msg=$request->input("msg");
        $money=$request->input("money");
        $array=array('name'=>$name,'mob'=>$mob,'msg'=>$msg,'money'=>$money);
        DB::table("donation")->insert($array);
        echo "<script>alert('Thanks for Review');window.location.href='/donation'</script>";
    }
    public function savesuggestion(Request $request)
    {
        $name=$request->input("name");
        $mob=$request->input("mob");
        $msg=$request->input("msg");
        $array=array('name'=>$name,'mob'=>$mob,'msg'=>$msg,);
        DB::table("suggestion")->insert($array);
        echo "<script>alert('Thanks for Review');window.location.href='/suggestion'</script>";
    }


}
