<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Admincontroller extends Controller
{
    //

    public function dashboard()
    {
        return view("Adminpages.dashboard");
    }
    public function Review()
    {
        $enq= DB::select("select * from review");
        return view("Adminpages.Review",['Review'=>$enq]);
    }
    public function memberdetail()
    {
        $enq= DB::select("select * from membership");
        return view("Adminpages.memberdetail",['membership'=>$enq]);
    }
    public function enquirymngt()
    {
       $enq= DB::select("select * from contactus");
        return view("Adminpages.enquirymngt",['contacts'=>$enq]);
    }
    public function suggestionmngt()
    {
        $enq= DB::select("select * from suggestion");
        return view("Adminpages.suggestionmngt",['suggestion'=>$enq]);
    }
    public function dynamicevent()
    {
        $enq= DB::select("select * from donation");
        return view("Adminpages.dynamicevent",['donation'=>$enq]);
    }
    public function changepass()
    {
        return view("Adminpages.changepass");
    }
    public function logout()
    {
        return view("Adminpages.logout");
    }
}
