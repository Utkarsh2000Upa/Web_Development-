@extends("Adminpages.AdminMaster")
@section("content")

<h1>this is donor page</h1>
@endsection
