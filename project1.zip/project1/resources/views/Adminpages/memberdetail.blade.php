@extends("Adminpages.AdminMaster")
@section("content")

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                    <tr>
                        <th>Id</th>
                        <th>name</th>
                        <th>mobile</th>
                        <th>email</th>
                        <th>father</th>
                        <th>password</th>
                        <th>confirmpassword</th>
                        <th>catchcode</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($membership as $x)
                        <tr>
                            <td>
                                {{ $x->id }}
                            </td>
                            <td>
                                {{ $x->name }}
                            </td>
                            <td>
                                {{ $x->mobile }}
                            </td>
                            <td>
                                {{ $x->email }}
                            </td>
                            <td>
                                {{ $x->father }}
                            </td>
                            <td>
                                {{ $x->password }}
                            </td>
                            <td>
                                {{ $x->confirmpassword }}
                            </td>
                            <td>
                                {{ $x->catchcode }}
                            </td>
                            <td>
                                <a href="#"><span class="fa fa-trash" style="color:red;"></span></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>

                </table>
            </div>
        </div>
    </div>

@endsection

