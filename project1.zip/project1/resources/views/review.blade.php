@extends('master')
@section('content')
    <script>
        $(document).ready(function(){
            $(".ss").click(function(){
                var d=$(this).attr('data');
                $("#hbn").val(d);
                for(var i=1;i<=5;i++)
                {
                    if(i<=d)
                    {
                        $("#s"+i).css("color","yellow");
                    }
                    else
                    {
                        $("#s"+i).css("color","red");
                    }
                }
            })
        })
    </script>

    <style>

    </style>
    <div class="container-fluid">

    <div class="row" style="background-color:lightgoldenrodyellow">
        <div class="col-sm-4">
            <a><img src="images/I10.jpg" style="height:600px;width:100%"></a>
        </div>
        <div class="col-sm-4" style="border: 4px solid blue;min-height: 300px;margin:5%">
            <h4 style="color: green">Places Give Review: </h4>
            <br>
            <form action="/saveReview/" method="post"><br>
                @csrf
                Name<br>
                <input type="text"name="name" placeholder="Your Name" class="form-control" style="background-color:lavender"/><br>
                Rating <br>
                <span class="fa fa-star ss" id="s1" data="1" style="font-size:50px;color:red"></span>
                <span class="fa fa-star ss" id="s2" data="2" style="font-size:50px;color:red"></span>
                <span class="fa fa-star ss" id="s3" data="3" style="font-size:50px;color:red"></span>
                <span class="fa fa-star ss" id="s4" data="4" style="font-size:50px;color:red"></span>
                <span class="fa fa-star ss" id="s5" data="5" style="font-size:50px;color:red"></span>
            <br><br>
            <textarea class="form-control" name="msg" placeholder="Messages" style="background-color:lavender"></textarea><br><br>
                <input type="hidden" id="hbn" name="hbn"/>
            <button class="btn btn-success">Submit</button>
            </form>
        </div>
        <div class="col-sm-4"></div>
    </div>
    </div>
    <br>
@endsection
