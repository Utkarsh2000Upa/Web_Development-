@extends('master')
@section('content')
    <script>
        function getCode()
        {
            var hexaCode="04255rASDDFyywgsg667737SFDSGSDGRDzcdgrgr";
            var code="";
            for(var i=0;i<6;i++)
            {
                code=code+hexaCode[Math.floor(Math.random()*12)];
            }
            return code;
        }
        function f1()
        {
            document.getElementById("sp1").innerHTML=getCode();
        }
        window.onload=f1;
    </script>

    <form action="/savemembership/" method="post">
        @csrf
            <div class="row" style="background-image:url('images/I14.jpg');background-repeat:no-repeat;background-size:cover;">
                <div class="col-sm-4">
                </div>
                <div class="col-sm-4" style="min-height:400px;border:3px solid teal;padding:10px;margin:30px; background: #2aabd2;color:greenyellow">
                    <h2 style="text-align:center;color:seashell"> Become A Member</h2>
                    <span class="fa fa-user"></span> Name
                    <input type="text" name="name" class="form-control" required/>
                    <span class="fa fa-phone"></span> Mobile Number
                    <input type="number" name="mob" class="form-control" required/>
                    <span class="fa fa-envelope"></span> Email Address
                    <input type="email"name="email" class="form-control" required/>
                    <span class="fa fa-user"></span> Father Name
                    <input type="text" name="father" class="form-control" required/>
                    <span class="fa fa-users"></span>   Gender </br>
                    <input type="radio"value="Male" name="g">Male
                    <input type="radio" value="FeMale" name="g">Female
                    <br>
                    <span class="fa fa-image"></span>  Profile Picture
                    <input type="file" name="file"class="form-control" required>
                    <span class="fa fa-lock"></span> Password
                    <input type="password" name="passwd" class="form-control" required><br>
                    <span class="fa fa-lock"></span>Confirm Password
                    <input class="password" type="password" name="conpasswd" class="form-control"style="color: black" required/><br>
                    Captcha Code<span style="font-size:30px;color:red;margin-left:2%" id="sp1">hjhhjh</span>
                    <span onclick="f1()" class="fa fa-refresh" style="font-size:30px;color:black;cursor:pointer;margin-left:5%;"></span>
                    <br>
                    Enter Above Catch Code<input type="text"name="code" style="height:35px;width:400px;color: black" required><br><br>
                    <button class="btn btn-danger">Register Now</button>
                </div>
                <div class="col-sm-4"></div>
            </div>
        </div>
    </form>

@endsection
