@extends('master')
@section('content')
<div class="row" style="margin:0%;background-color:linen">
    <div class="col-sm-12" style="border: 2px solid red;margin-right: 15%">
        <h3 style="color: teal">Swachh Bharat Scheme</h3>
        <ol>
        <li>To accelerate the efforts to achieve universal sanitation coverage and to put focus on sanitation, the Prime Minister of India launched the Swachh Bharat Mission on 2nd October, 2014. The Mission Coordinator for SBM is Secretary, Ministry of Drinking Water and Sanitation (MDWS) with two Sub-Missions, the Swachh Bharat Mission (Gramin) and the Swachh Bharat Mission (Urban). Together, they aim to achieve Swachh Bharat by 2019, as a fitting tribute to Mahatma Gandhi on his 150th Birth Anniversary.
            In Rural India, this would mean improving the levels of cleanliness through Solid and Liquid Waste Management activities and making villages Open Defecation Free (ODF), clean and sanitised.</li><br><br>
        <li>Swachh Bharat Mission in villages In 1999, the then central government had launched a scheme that was called the Nirmal Bharat Abhiyan. It was also known as the TSC or Total Sanitation Campaign, and was targeted towards better sanitation facilities in rural localities.</li><br><br>
        <li>The programme aims to provide separate toilets for boys and girls in all government schools within one year. The ministry financially supports states and union territories to provide toilets for girls & boys in schools under the Sarva Shiksha Abhiyan (SSA) and Rashtriya Madhyamik Shiksha Abhiyan (RMSA).</li><br><br>
            <li>India is no longer a land of snake charmers and rope tricks. The central as well as the state governments are working in unison to promote the modern face of the nation. India has achieved several feats in technical, economic and scientific sectors. But one problem that looms large and tarnishes the country’s image is unsanitary surroundings. Massive population and lack of proper sanitization are the main reasons of this problem. Mahatma Gandhi was a supporter of sanitary conditions and stressed on the need to create awareness among the people.</li><br><br>
            <li>The current central government, under the leadership of Narendra Modi launched a pan-nation scheme that honored the view and wishes of the “Father of the Nation.” The former government launched a similar scheme, but was unable to implement it successfully. Narendra Modi made sure that all loopholes were sealed off to pave the path for the proper implementation of Swachh Bharat Mission or Swachh Bharat Abhiyan.</li><br><br>
        </ol>
        <video controls=""  style="margin-left:100px;width:1000px;">
            <source src="images/Swachh Bharat.mp4" type="video/mp4">
        </video><br><br>
        <img src="images/I13.jpg" style="margin-left:220px;height:300px;width: 600px">
        <h3 style="color: teal">Vision</h3>
        <p>The aim of Swachh Bharat Mission (Gramin) is to achieve a clean and Open Defecation Free (ODF) India by 2nd October, 2019</p>
        <h3 style="color: teal">Objectives</h3>
        <p>To bring about an improvement in the general quality of life in the rural areas, by promoting cleanliness, hygiene and eliminating open defecation.
            To accelerate sanitation coverage in rural areas to achieve the vision of Swachh Bharat by 2nd October 2019.
            To motivate communities to adopt sustainable sanitation practices and facilities through awareness creation and health education.
            To encourage cost effective and appropriate technologies for ecologically safe and sustainable sanitation.
            To develop, wherever required, community managed sanitation systems focusing on scientific Solid & Liquid Waste Management systems for overall cleanliness in the rural areas.
            To create significant positive impact on gender and promote social inclusion by improving sanitation especially in marginalized communities</p>
        <h3 style="color: teal">Strategy</h3>
        <p>The focus of the Strategy is to move towards a ‘Swachh Bharat’ by providing flexibility to State governments, as sanitation is a State subject, to decide on their implementation policy, use of funds and mechanisms, taking into account State specific requirements. The Government of India’s role is essentially to complement the efforts of the State governments through the focused programme being given the status of a Mission, recognizing its dire need for the country.</p>
        <h3 style="color: teal">The key elements of the Strategy include</h3>
        <ol>
            <li>Augmenting the institutional capacity of districts for undertaking intensive behaviour change activities at the grassroots level</li>
            <li>Strengthening the capacities of implementing agencies to roll out the programme in a time-bound manner and to measure collective outcomes</li>
            <li>Incentivizing the performance of State-level institutions to implement behavioural change activities in communities.</li>
        </ol>
    </div>
</div>
    <br><br><br>
@endsection
