<html>
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width,initial-state=1"/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link href="css/hover.min.css" rel="stylesheet"/>
    <link href="css/style.css" rel="stylesheet"/>
    <style>
        button
        {
            padding:15px 25px;
            margin:20px;
            font-size:16px;
            letter-spacing: 1px;
            border: 2px solid #ffc107;
            color:#ffff00;
            cursor:pointer;
            background: linear-gradient(to right,transparent 20%,#ffc107);
            background-size:200% ;
            background-position: left;
            transition: background-position 0.5s;
        }
        button:hover
        {
            background-position: right;
            color:red;
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row" style="min-height: 20px">
        <div class="col-sm-3" style="margin-top: 12px">
            <a href="#"><img class="logo" src="images/flag.gif">
                <font>Government of india</font></a>
        </div>
        <div class="col-sm-6">
            <h2 style="text-align:center;margin-top:10px;padding:0px; color:darkmagenta"><marquee behavior="alternate" scrollamount="8">SWACHH BHARAT ABHIYAN</marquee></h2>
        </div>
        <div class="col-sm-3">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="https://www.facebook.com/login/?next=https%3A%2F%2Fwww.facebook.com%2FSBMGramin%2F" style="border-right:1px solid black;color:blue"><span class="fa fa-facebook" style="font-size: 20px;font-weight:50"></span></a></li>
                <li><a href="https://twitter.com/swachhbharat" style="border-right:1px solid black; color:darkblue"><span class="fa fa-twitter" style="font-size: 20px;font-weight:50"></span></a></li>
                <li><a href="https://www.youtube.com/channel/UCo_Itwq5Oyfq7Jk4Soik-UA" style="border-right:1px solid black; color:red"><span class="fa fa-youtube" style="font-size: 20px;font-weight:50"></span></a></li>
                <li><a href="login" style="border-right:1px solid black"><span class="fa fa-user" style="font-size:20px;"></span>Login</a></li>
            </ul>
        </div>
    </div>
    <div class="row" style="padding: 0px;margin-top: 0px">
        <div class="col-md-1" style="min-height:100px;background:teal;"></div>
        <div class="col-md-3" style="min-height:100px;background: teal;">
            <img src="images/logo.png" height="100" width="100%"/>
        </div>
        <div class="col-md-8" style="padding:0px;min-height:100px;">
            <nav class="navbar navbar-default menu">
                <ul class="nav navbar-nav" style="background:teal">
                    <li><a href=" " style="color:white;"><span class="fa fa-home">Home</span></a></li>
                    <li><a href="/scheme" style="color:white"><span class="fa fa-th-list">Scheme</span></a></li>
                    <li><a href="membership" style="color:white"><span class="fa fa-users">Membership</span></a></li>
                    <li><a href="contact" style="color:white"><span class="fa fa-phone">contact Us</span></a></li>
                    <li><a href="login" style="color:white"><span class="fa fa-user">Login</span></a></li>
                    <li><a href="#" style="color:white">Donation</a></li>
                    <li><a href="#" style="color:white">Member</a></li>
                    <li><a href="#" style="color:white">Suggestion</a></li>
                    <li><a href="#" style="color:white"><span class="fa fa-picture-o">Image Gallery</span></a></li>
                    <li><a href="#" style="color:white"><span class="">Social media</span></a></li>
                </ul>
            </nav>
        </div>
    </div>
    <div class="row" style="margin-top: 0px">
        <div  id="dt" class="carousel slide" data-ride="carousel">
            <!--Apply for Indicator-->
            <ol class="carousel-indicators">
                <li background="blue" data-target="#dt" data-slide-to="0" class="active"></li>
                <li background="blue" data-target="#dt" data-slide-to="1" class="active"></li>
                <li  background="blue" data-target="#dt" data-slide-to="2" class="active"></li>
                <li background="blue" data-target="#dt" data-slide-to="3" class="active"></li>

            </ol>
            <!--End class-->
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img src="images/sw1.png" height="500" width="100%"/>
                </div>
                <div class="item">
                    <img src="images/modi.jpg" height="500" width="100%"/>
                </div>
                <div class="item">
                    <img src="images/what.jpg" height="500" width="100%"/>
                </div>
                <div class="item">
                    <img src="images/e-waste.jpg" height="500" width="100%"/>
                </div>
                <div class="item">
                    <img src="images/sw2.jpg" height="500" width="100%"/>
                </div>
                <div class="item">
                    <img src="images/ministry.jpg" height="500" width="100%"/>
                </div>
                <a class="left carousel-control" href="#dt" role="button" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    <span class="sr-only">previous</span>

                </a>
                <a class="right carousel-control" href="#dt" role="button" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="sr-only">next</span></a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-2" style="min-height:100px;background:white">
            <div style="height:80px;width:100px;background:green;border-radius:70% 70% 70% 70%;margin-top:10px;margin-left:80px;padding:20px">
                <p align="center">  <font size="6" color="white"><b>100</b></font></p>
            </div>
        </div>
        <div class="col-md-1" style="min-height:100px;background:white;text-align:left;font-size:15px;padding:27px">
            Hours Mission
        </div>
        <div class="col-md-9" style="min-height:100px;background:white;border-left:1px solid green;">
            <div class="carousel-inner" role="listbox">
                <div class="text active">
                    <span>Swachh Bharat Abhiyan</span><p>Prime Minister Shri Narendra Modi Launched the ambitious 'Swachh Bharat Abhiyan' (Clean India Mission) 2nd October 2014The 'Abhiyan' was launched on the ocassion of Mahatama Gandhi's 145th birth anniversary</p>
                </div>
                <div class="text">
                    <span>Lets keep it clean</span>
                    <p>Millions of students and youth taking pledge for a clean India. It is our country</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12" style="min-height:100px;background:teal">
            <div class="container">
                <div class="row">
                    <div class="col-md-2" style="min-height:100px;background:teal;text-align:center;font-size:15px;padding:10px;">
                        <font color="white">    1,03,645</font><br>
                        <font color="lightblue">  SWACHH BHARAT</font><br>
                        <font color="white">  PLEDGES TAKEN</font>
                    </div>
                    <div class="col-md-2" style="min-height:100px;background:teal;text-align:center;font-size:15px;padding:10px;">
                        <font color="white">  24,799</font><br>
                        <font color="lightblue">  SWACHH BHARAT</font><br>
                        <font color="white">  CHHALLENGES TAKEN</font>
                    </div>
                    <div class="col-md-2" style="min-height:100px;background:teal;text-align:center;font-size:15px;padding:10px;">
                        <font color="white">    26,563</font><br>
                        <font color="lightblue">  SWACHH BHARAT</font><br>
                        <font color="white">  ACTIVITIES DONE</font>
                    </div>
                    <div class="col-md-2" style="min-height:100px;background:teal;text-align:center;font-size:15px;padding:10px;">
                        <font color="white">    51,362</font><br>
                        <font color="lightblue">  SWACHH BHARAT</font><br>
                        <font color="white">  ACTIVE PARTICIPANT</font>
                    </div>
                    <div class="col-md-2" style="min-height:100px;background:teal;text-align:center;font-size:15px;padding:10px;">
                        <font color="white">    13,71,538</font><br>
                        <font color="lightblue">  SWACHH BHARAT</font><br>
                        <font color="white">  CONTRIBUTED HOURS</font>
                    </div>
                    <div class="col-md-2" style="min-height:100px;background:teal;text-align:center;font-size:15px;padding:10px;">
                        <font color="white">    6,106</font><br>
                        <font color="lightblue">  SWACHH BHARAT</font><br>
                        <font color="white">  PAKHWADA ACTIVITIES</font>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" style="min-height:100px;background:white;text-align:center;font-size:30px;padding:30px;">
            <h2>  <font color="teal">   Swachh Bharat PinBoard</font></h2>
        </div>
        <div class="row">
            <div class="col-md-12" style="min-height:800px;background:white;border-bottom:1px solid black">
                <div class="container">
                    <div class="row">
                        <div class="col-md-1" style="min-height:300px;background:white"></div>
                        <div class="col-md-3" style="min-height:300px;background:white;padding:0px">
                            Swachhbharat Activity
                            <img src="images/clean_4.jpg" height="200" width="100%"/>
                            <a href="https://swachhbharat.mygov.in/challenge/general-cleanliness-common-area-2nd-floor">General cleanliness in common area 2nd floor</a>
                            <p>General cleanliness in common area 2nd floor(Electronics niketan)</p>
                        </div>
                        <div class="col-md-1" style="min-height:300px;background:white"></div>
                        <div class="col-md-3" style="min-height:400px;background:white;padding:0px">
                            Swachhbharat Activity
                            <img src="images/mygov_.jpg" height="200" width="100%"/>
                            <a href="https://swachhbharat.mygov.in/challenge/plastic-free-chandigarh-campaign-launched-mayor-chd-smtsarbjit-kaur-and-msanindita-mitra">"Plastic Free Chandigarh" campaign launched by Mayor Chd Smt.Sarbjit
                                Kaur and Mrs.Anindita Mitra,IAS,MCC Commissioner</a>
                            <p>"Plastic Free Chandigarh" campaign launched by Mayor Chd, Smt.Sarbjit Kaur and Ms.Anindita</p>
                        </div>
                        <div class="col-md-1" style="min-height:300px;background:white"></div>
                        <div class="col-md-3" style="min-height:300px;background:white;padding:0px">
                            Swachhbharat AActivity
                            Swachhbharat Activity
                            <img src="images/after_cleaning.jpg" height="200" width="100%"/>
                            <a href="https://swachhbharat.mygov.in/challenge/general-cleanliness-common-areas-electronic-niketan-building-0">General cleanliness of common areas(Electronic niketan building)</a>
                            <p>General cleanliness of common areas (Electronic niketan building)</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-1" style="min-height:300px;background:white;"></div>
                        <div class="col-md-3" style="min-height:350px;background:white;">
                            Swachhbharat Activity
                            <img src="images/swachh.jpg" height="200" width="100%"/>
                            <a href="https://swachhbharat.mygov.in/challenge/swacchta-pakhwara-c-met-hyderabad-0">Swachhta Pakhwada at C-MET Hyderabad</a>
                            <p>As part of Swacchta Pakhwara occasion, we at C-MET Hyderabad gathered for cleaning drive in C-MET Hy</p>
                        </div>
                        <div class="col-md-1" style="min-height:300px;background:white;"></div>
                        <div class="col-md-3" style="min-height:300px;background:white;">
                            Swachhbharat Activity
                            <img src="images/abhiyan.jpg" height="200" width="100%"/>
                            <a href="https://swachhbharat.mygov.in/challenge/swacchta-pakhwara-c-met-hyderabad">Swachhta Pakhwada at C-MET Hyderabad</a>
                            <p>Clean drive is carried out in C-MET premises</p>
                        </div>
                        <div class="col-md-1" style="min-height:300px;background:white;"></div>
                        <div class="col-md-3" style="min-height:300px;background:white;">
                            Swachhbharat Activity
                            <img src="images/sir.jpg" height="200" width="100%"/>
                            <a href="https://swachhbharat.mygov.in/challenge/general-cleaning-common-areas-0">General cleaning  of common areas(Electronic niketan building 3rd floor) </a>
                            <p>General cleaning of common areas( Electronic niketan building 3rd floor).</p>
                        </div>
                        <button><a href="https://drive.google.com/drive/folders/0B_844xS4yWX-eUhhN1dVQVBEMm8">Download Swachh Bharat Ringtone</a></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12" style="min-height:400px;background:white">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-4" style="min-height:400px;background:white;border-right:1px solid black">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h3 style="margin-left:0px;padding:0px;margin-top:30px;color:teal"><b>About SBM</b></h3>
                                </div>
                                <div class="col-sm-6">
                                    <img src="images/sw16.jpg" style="height:80px;width:80px"/>
                                </div>
                            </div>
                            <p>To accelerate the efforts to achieve universal sanitation coverage and to put the focus on sanitation, the Prime Minister of India had launched the Swachh Bharat Mission on 2nd October 2014. Under the mission, all villages, Gram Panchayats, Districts, States and Union Territories in India declared themselves "open-defecation free" (ODF) by 2 October 2019, the 150th birth anniversary of Mahatma Gandhi, by constructing over 100 million toilets in rural India. To ensure that the open defecation free behaviours are sustained, no one is left behind, and that solid and liquid waste management facilities are accessible, the Mission is moving towards the next Phase II of SBMG i.e ODF-Plus. ODF Plus activities under Phase II of Swachh Bharat Mission (Grameen) will reinforce ODF behaviours and focus on providing interventions for the safe management of solid and liquid waste in villages.</p>

                        </div>
                        <div class="col-md-4" style="min-height:400px;background:white;text-align:center;padding:40px;border-right:1px solid black">
                            <h3>Swachh Bharat</h3>
                            <b><font size="5" color="teal">ACTIVITY</font></b>
                            <p>Swachh Bharat Activity enables you to share “before” and “after” pictures and videos of your contribution to Swachh Bharat Abhiyan.</p>

                        </div>
                        <div class="col-md-4" style="min-height:400px;background:white;padding:10px;text-align:center;">
                            <img src="images/OIP.jpg" height="250" width="100%" style="padding:20px;padding-left:15px"/>
                            <p align="left"><font size="4"><b>Contribute</b> in making <b>India clean</b> by the <b>150th birth anniversary</b> of <b>Mahatma Gandhi.</b></font></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12" style="min-height:180px;background:darkslategrey;border-bottom:1px solid white">
                <div class="container">
                    <div class="row">
                        <div class="col-md-2" style="min-height:180px;background:darkslategrey;text-align:left;font-size:14px;padding:20px;margin-top: 50px">

                            <a href="https://swachhbharat.mygov.in/" style="color:lightgray">Home</a><br>
                            <a href="https://secure.mygov.in/feedback/" style="color:lightgray">Feedback</a><br>
                            <a href="https://www.mygov.in/simple-page/associate-mygov/" style="color:lightgray">Associate With Mygov</a><br>
                            <a href="https://swachhbharat.mygov.in/shs-2019" style="color:lightgray">SHS 2019</a><br>

                        </div>
                        <div class="col-md-2" style="min-height:200px;background:darkslategrey;text-align:left;font-size:14px;padding:20px;margin-top: 50px">
                            <a href="https://www.mygov.in/overview/" style="color:lightgray">About us</a><br>
                            <a href="https://www.mygov.in/sitemap/" style="color:lightgray">Sitemap</a><br>
                            <a href="https://www.mygov.in/simple-page/link-us/" style="color:lightgray">Link to us</a><br>
                            <a href="https://swachhbharat.mygov.in/swachhata-pakhwada-meity" style="color:lightgray">Swachhta Pakhwada 2020 Activities</a><br>

                        </div>
                        <div class="col-md-2" style="min-height:200px;background:darkslategrey;text-align:left;font-size:14px;padding:25px;margin-top: 50px">
                            <a href="https://www.mygov.in/simple-page/terms-conditions/" style="color:lightgray">Terms & Condition</a><br>
                            <a href="https://www.mygov.in/mygov-faq/" style="color:lightgray">FAQ</a><br>
                            <a href="https://www.mygov.in/simple-page/contact-us/" style="color:lightgray">Contact Us</a><br>

                        </div>
                        <div class="col-md-1" style="min-height:200px;background:darkslategrey;padding:0px;margin-top:50px;">
                            <a href="" class="logo"><img src="images/qr.jpg" height="100" width="100"/></a>
                        </div>
                        <div class="col-md-5" style="min-height:200px;background:darkslategrey;margin-top: 50px">
                            <a href="" class="logo"><img src="images/footer-logo.png" height="50" width="100"/></a>
                            <p><font color="white">MyGov platform is designed, developed and hosted by National Informatics Centre, Ministry of Electronics & Information Technology, Government of India.</font></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3" style="min-height:50px;background:lightslategray"></div>
        <div class="col-md-6" style="min-height:50px;background:lightslategray">
            <div class="row">
                <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                    <img src="images/sw3.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                    <img src="images/sw4.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                    <img src="images/sw5.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                    <img src="images/sw6.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                    <img src="images/sw7.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:lightslategray;border-right:1px solid white">
                    <img src="images/sw8.png" height="50" width="100%"/>
                </div>
            </div>
        </div>
        <div class="col-md-3" style="min-height:50px;background:lightslategray">
            <img src="images/sw9.png" height="50" width="100" style="border-right:1px solid white"/>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3" style="min-height:50px;background:black"></div>
        <div class="col-md-6" style="min-height:50px;background:black">
            <div class="row">
                <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                    <img src="images/sw10.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                    <img src="images/sw11.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                    <img src="images/sw12.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                    <img src="images/sw13.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:black;border-right:1px solid white">
                    <img src="images/sw14.png" height="50" width="100%"/>
                </div>
                <div class="col-md-2" style="min-height:50px;background:black;">
                    <img src="images/sw15.png" height="50" width="100%"/>
                </div>
            </div>
        </div>
        <div class="col-md-3" style="min-height:50px;background:black"></div>

    </div>
</div>
</body>
</html>
<?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/index.blade.php ENDPATH**/ ?>