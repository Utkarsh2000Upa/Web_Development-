<?php $__env->startSection('content'); ?>

<h1>This is Member Page</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/member.blade.php ENDPATH**/ ?>