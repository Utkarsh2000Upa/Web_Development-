<?php $__env->startSection('content'); ?>
    <style>
    .container .contact-form {
    width: 50%;
    margin-left: 2%;
    float: left;
    }
    .container .contact-form .title {
    font-size: 2em;
    font-family: "Roboto", sans-serif;
    font-weight: 700;
    color: #242424;
    margin: 5% 8%;
    }
    .container .contact-form .subtitle {
    font-size: 1.2em;
    font-weight: 400;
    margin: 0 4% 5% 8%;
    text-align: center;
    }
    .container .contact-form input,
    .container .contact-form textarea {
    width: 300px;
    padding: 3%;
    margin: 2% 8%;
    color: #242424;
    border: 1px solid #B7B7B7;
    }
    .container .contact-form input::placeholder,
    .container .contact-form textarea::placeholder {
    color: #242424;
    }
    .container .contact-form .btn-send {
    background: #A383C9;
    width: 100px;
    height: 40px;
    color: #FFFFFF;
    font-weight: 700;
    margin: 2% 8%;
    border: none;
    }
    </style>
<div class="container-fluid" style="padding:0px;margin: 0%;background-color: lightblue">
        <div class="row">
            <div class="col-sm-6">
                <div class="container" style="border: 2px solid black;width:500px;margin:5%;background-color:white;">
                    <div class="contact-form" style="margin-left:15%">
                        <h1 class="title" style="color:teal;margin-left:25%">Contact Us</h1>
                        <h3 class="subtitle">We are here assist you.</h3>
                        <form action="/savecontact/" method="post">
                            <?php echo csrf_field(); ?>
                            <span class="fa fa-user" style="color:red"><b>Name:</b></span><br>
                            <input type="text" name="name" placeholder="Your Name" required/><br>
                            <br>
                            <span class="fa fa-envelope" style="color:red"><b>Email:</b></span><br>
                            <input type="email" name="email" placeholder="Your E-mail Address" required/><br><br>
                            <span class="fa fa-phone" style="color:red"><b>Mobile:</b></span><br>
                            <input type="tel" name="mob" placeholder="Your Mobile Number" required/><br><br>
                            <span class="fa fa-male" style="color: red"><b>Query:</b></span><br>
                            <textarea name="message" id="" rows="8" placeholder="Your Message" required></textarea><r><br></r>
                            <button class="btn btn-send">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.8948932833064!2d80.95128751457058!3d26.87508028314384!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfdd563c25cbf%3A0xbcefbb4f300d416c!2sMecatredz%20Technology%20Pvt%20Ltd%20Lucknow!5e0!3m2!1sen!2sin!4v1662168716963!5m2!1sen!2sin" width="100%" height="600" style="border: 1px solid black;margin-top: 50px" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/contactUs.blade.php ENDPATH**/ ?>