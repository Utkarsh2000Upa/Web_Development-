<?php $__env->startSection('content'); ?>

<div class="row" style="margin:1%;background-color:lavender">
    <div class="col-sm-12">
        <h2 style="color: #d58512"><b>How To Donate To Swachh Bharat Kosh:</b></h2>
        <br>
        <h3 style="color: #2e59d9"><u>Swachh Bharat Kosh, an effort to fund the Swachh Bharat Campaign invites donations from individuals and corporates. Any individual or corporate can make donation of any desired amount into the Swachh Bharat Kosh. The government urges Indian citizens and companies to donate generously to achieve the objective of clean India.</u></h3>
        <br><br>
        <p>Corporates can discharge their statutory CSR liabilities under the Companies Act 2013, by simply contributing to Swachh Bharat Kosh. Donations to the “Swachh Bharat Kosh”, other than the sums spent for “Corporate Social Responsibility” are eligible for 100% deduction under section 80G of the Income-tax Act.

            All Donations would be acknowledged. Further, high value contributors will also get Letter of Thanks from senior officers as under:</p>
        <br>
        </div>
    <div class="row" style="margin-left:7%;background-color:lavender">
        <div class="col-sm-6">
       <h4 style="color: teal">How Do Donate?</h4>
        <span><b>Donations can be made to Swachh Bharat Kosh as per following details:<br>
            Account No: 34215500587<br>
            Bank Name: State Bank of India<br>
            Branch Name: Central Secretariat Branch<br>
            Branch Code: 00625<br>
            Address: North Block, New Delhi 110 001<br>
            Email: sbi.00625@sbi.co.in<br>
            IFSC Code: SBIN0000625<br>
            MICR No.: 110002014<br>
            SWIFT Code: SBININBB373<br>
            PAN No.: AAPTS3635L</b></span>
        </div>
        <div class="col-sm-6">
           <form action="/savedonation/" method="post" style="border:2px solid black;height:420px;width:300px;background-color: lightgreen;margin: 2%">
               <?php echo csrf_field(); ?>
               <h4>Donation Form:</h4><br>
               <span>Name</span><br>
               <input type="text" name="name" placeholder="Name"><br><br>
               <span>Mobile</span><br>
               <input type="number" name="mob" placeholder="Mobile"><br><br>
               <span>purpose of donation </span><br>
               <textarea class="form-control" name="msg" placeholder="Messages"></textarea><br>
               <span>Money</span><br>
               <input type="number" name="money"><br><br>
               <button class="btn btn-success">Submit</button>
           </form>
        </div>
    </div>
        <h3  style="color: teal">Objectives of Swachh Bharat Kosh</h3>
        <ol>
            <li>Construction of Community/individual toilets in rural areas, urban areas, in government schools & Aanganwaadis</li>
            <li>Renovation and repair of dysfunctional community/individual toilets in government schools, Aanganwadis, Construction activity for water supply to the constructed toilet</li>
            <li>Training and skill development to facilitate maintenance of constructed toilets and to ensure its inter- linkages with education on hygiene</li>
            <li>Other initiatives of improving sanitation and cleanliness in rural and urban areas including solid and liquid waste management</li>
            <li>Any other activity to improve sanitation in the country</li>
        </ol>
        <h3 style="color: teal">Swachh Bharat Kosh Donation Advertisement</h3>
        <img src="images/I12.jpg" style="margin-left: 150px;height:500px;width:900px">
        <br><br>
    </div>
</div>
    <br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/donation.blade.php ENDPATH**/ ?>