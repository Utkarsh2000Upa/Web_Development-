<?php $__env->startSection('content'); ?>

    <!------ Include the above in your HEAD tag ---------->
    <style>
        span{
            font-size:15px;
        }
        /*a{
            text-decoration:none;
            color: #0062cc;
            border-bottom:2px solid #0062cc;
        }*/


        .box-part{
            background:#FFF;
            border-radius:0;
            padding:60px 10px;
            margin:30px 0px;
        }
        .text{
            margin:20px 0px;
        }
    </style>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <div class="box">
        <div class="container">
            <div class="row">

                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

                    <div class="box-part text-center">

                        <i class="fa fa-instagram fa-3x" style="color:magenta" aria-hidden="true"></i>

                        <div class="title">
                            <h4>Instagram</h4>
                        </div>

                        <div class="text">
                            <span> the Prime Minister of India had launched the Swachh Bharat Mission on 2nd October 2014. </span>
                        </div>

                        <a href="https://www.instagram.com/accounts/login/">Learn More</a>

                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

                    <div class="box-part text-center">

                        <i class="fa fa-twitter fa-3x" aria-hidden="true" style="color:blue"></i>

                        <div class="title">
                            <h4>Twitter</h4>
                        </div>

                        <div class="text">
                            <span>the Prime Minister of India had launched the Swachh Bharat Mission on 2nd October 2014.</span>
                        </div>

                        <a href="https://twitter.com/SwachhBharatGov">Learn More</a>

                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

                    <div class="box-part text-center">

                        <i class="fa fa-facebook fa-3x" aria-hidden="true" style="color:blue"></i>

                        <div class="title">
                            <h4>Facebook</h4>
                        </div>

                        <div class="text">
                            <span>the Prime Minister of India had launched the Swachh Bharat Mission on 2nd October 2014.</span>
                        </div>

                        <a href="https://www.facebook.com/JoinSwachhBharatAbhiyan2014">Learn More</a>

                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

                    <div class="box-part text-center">

                        <i class="fa fa-pinterest-p fa-3x" style="color:#e02d1b" aria-hidden="true"></i>

                        <div class="title">
                            <h4>Pinterest</h4>
                        </div>

                        <div class="text">
                            <span>the Prime Minister of India had launched the Swachh Bharat Mission on 2nd October 2014.</span>
                        </div>

                        <a href="https://in.pinterest.com/lalit1592artist/swachh-bharat-abhiyan/">Learn More</a>

                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

                    <div class="box-part text-center">

                        <i class="fa fa-google-plus fa-3x" style="color:orange" aria-hidden="true"></i>

                        <div class="title">
                            <h4>Google</h4>
                        </div>

                        <div class="text">
                            <span>the Prime Minister of India had launched the Swachh Bharat Mission on 2nd October 2014.</span>
                        </div>

                        <a href="https://swachhbharatmission.gov.in/sbmcms/index.htm">Learn More</a>

                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">

                    <div class="box-part text-center">

                        <i class="fa fa-youtube fa-3x " style="color:red" aria-hidden="true"></i>

                        <div class="title">
                            <h4>YouTube</h4>
                        </div>

                        <div class="text">
                            <span>the Prime Minister of India had launched the Swachh Bharat Mission on 2nd October 2014.</span>
                        </div>

                        <a href="https://www.youtube.com/watch?v=Ej22NMueDoE">Learn More</a>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/Media.blade.php ENDPATH**/ ?>