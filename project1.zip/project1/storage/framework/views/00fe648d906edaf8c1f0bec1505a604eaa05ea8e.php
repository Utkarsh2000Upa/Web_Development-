<?php $__env->startSection("content"); ?>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
    <script>
        $(document).ready(function(){
            $('.pass_show').append('<span class="ptxt">Show</span>');
        });


        $(document).on('click','.pass_show .ptxt', function(){

            $(this).text($(this).text() == "Show" ? "Hide" : "Show");

            $(this).prev().attr('type', function(index, attr){return attr == 'password' ? 'text' : 'password'; });

        });
    </script>
    <style>
        .pass_show{position: relative}

        .pass_show .ptxt {

            position: absolute;

            top: 50%;

            right: 10px;

            z-index: 1;

            color: #f36c01;

            margin-top: -10px;

            cursor: pointer;

            transition: .3s ease all;

        }

        .pass_show .ptxt:hover{color: #333333;}
    </style>

    <div class="container">
        <div class="row">
            <div class="col-sm-4">
             <form action="/savepassword/" method="post">
                 <?php echo csrf_field(); ?>
                <label>Current Password</label>
                <div class="form-group pass_show">
                    <input type="password" name="cpass"  class="form-control" placeholder="Current Password">
                </div>
                <label>New Password</label>
                <div class="form-group pass_show">
                    <input type="password" name="npass"  class="form-control" placeholder="New Password">
                </div>
                <label>Confirm Password</label>
                <div class="form-group pass_show">
                    <input type="password" name="pass" class="form-control" placeholder="Confirm Password">
                </div>
                 <button>Save</button>
             </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("Adminpages.AdminMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/Adminpages/changepass.blade.php ENDPATH**/ ?>