<?php $__env->startSection("content"); ?>
    <style>
        a
        {
         color:white;
            text-align: center;
            size:50px;
        }
    </style>
    <div class="container-fluid">
<div class="row">
    <div class="col-sm-3 btn-danger" style="min-height: 100px;margin:3%;">
        <a href="dynamicevent" style="text-align: center;size:20px ">Donor Management</a>
    </div>
    <div class="col-sm-3 btn-info" style="min-height: 100px;margin:3%;">
        <a href="enquirymngt">Enquiry Management</a>
    </div>
    <div class="col-sm-3 btn-warning" style="min-height: 100px;margin:3%;">
        <a href="memberdetail">Member Detail</a>
    </div>
</div>
<div class="row">
    <div class="col-sm-3 btn-danger" style="min-height: 100px;margin:3%;">
        <a  href="suggestionmngt">Suggestion Management</a>
    </div>
    <div class="col-sm-3 btn-info" style="min-height: 100px;margin:3%;">
        <a href="changepass">Change Password</a>
    </div>
    <div class="col-sm-3 btn-warning" style="min-height: 100px;margin:3%;">
        <a href="logout">Logout</a>
    </div>
</div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("Adminpages.AdminMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/Adminpages/dashboard.blade.php ENDPATH**/ ?>