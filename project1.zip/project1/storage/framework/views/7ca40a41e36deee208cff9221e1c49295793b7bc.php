<?php $__env->startSection("content"); ?>

    <h1>
        this si changeg pasfads
    </h1>

<?php $__env->stopSection(); ?>



<?php echo $__env->make("Adminpages.AdminMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/Adminpages/utkarsh.blade.php ENDPATH**/ ?>