<?php $__env->startSection("content"); ?>

<div class="container">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-bordered">
                    <thead class="table-dark">
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Rating</th>
                        <th>Message</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($x->id); ?>

                            </td>
                            <td>
                                <?php echo e($x->name); ?>

                            </td>
                            <td>
                                <?php echo e($x->rating); ?>

                            </td>
                            <td>
                                <?php echo e($x->msg); ?>

                            </td>
                        
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("Adminpages.AdminMaster", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swachhbharat\Swachhbharat\resources\views/Adminpages/Review.blade.php ENDPATH**/ ?>