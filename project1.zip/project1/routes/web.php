<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Homecontroller;
use App\Http\Controllers\Admincontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function (){
return view('Index');
});
Route::get('Index/',[Homecontroller::class,'Index']);
Route::get('scheme/',[Homecontroller::class,'Scheme']);
Route::get('login/',[Homecontroller::class,'Login']);
Route::get('membership/',[Homecontroller::class,'membership']);
Route::get('donation/',[Homecontroller::class,'Donation']);
Route::get('image/',[Homecontroller::class,'image']);
Route::get('suggestion/',[Homecontroller::class,'suggestion']);
Route::get('member/',[Homecontroller::class,'member']);
Route::get('Media/',[Homecontroller::class,'Media']);
Route::get('contact/',[Homecontroller::class,'contactUs']);
Route::get("/dashboard",[Admincontroller::class,"dashboard"]);
Route::get("/Review",[Admincontroller::class,"Review"]);
Route::get("/memberdetail",[Admincontroller::class,'memberdetail']);
Route::get("/enquirymngt",[Admincontroller::class,"enquirymngt"]);
Route::get("/suggestionmngt",[Admincontroller::class,"suggestionmngt"]);
Route::get("/dynamicevent",[Admincontroller::class,"dynamicevent"]);
Route::get("/changepass",[Admincontroller::class,"changepass"]);
Route::get("/logout",[Admincontroller::class,"logout"]);
Route::post('savecontact/',[Homecontroller::class,'savecontact']);
Route::post('savelogin/',[Homecontroller::class,'savelogin']);
Route::get("/review",[Homecontroller::class,'review']);
Route::post("/saveReview",[Homecontroller::class,"saveReview"]);
Route::post("/savemembership",[Homecontroller::class,"savemembership"]);
Route::post("/savepassword",[Admincontroller::class,"savepassword"]);
Route::post("/loginRecord",[Homecontroller::class,'loginRecord']);
Route::post('/savedonation',[Homecontroller::class,'savedonation']);
Route::post('/savesuggestion',[Homecontroller::class,'savesuggestion']);
