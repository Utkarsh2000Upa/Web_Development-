<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Membership extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create("membership",function (Blueprint $table){
            $table->increments('id');
            $table->string('name');
            $table->string('mobile');
            $table->string('email');
            $table->string('father');
            $table->string('gender');
            $table->string('file');
            $table->string('password');
            $table->string('confirmpassword');
            $table->string('catchcode');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::drop("membership");
    }
}
